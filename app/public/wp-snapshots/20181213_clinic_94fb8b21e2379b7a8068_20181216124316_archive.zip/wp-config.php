<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'juCagjrpUKCdIyA3+SXuXNomdNGTa12mIp2yg5tyhb3BisnwjJDkXduoxsxkpU2n1OMYoY6UPFf52SOXSXmJsg==');
define('SECURE_AUTH_KEY',  'AKvrCeShiR1vpXR9VaAwzYVO8vIc01vUkQxxXZ5KcxcRooLujg2dr0LTp7ojHnMLwywBopXldZUWrE7Yp54+/w==');
define('LOGGED_IN_KEY',    '0AbW8RPpRBjZK06VRFVL2FO3P8N20djY++R6HaDtBxli1Io7WhY8KrbzucD9Pe/0Vyfzg8FQLyECSwGdr93lkg==');
define('NONCE_KEY',        'nwliUAerpHxZ/zanrTo452MPjK3olUrxhJthgNKlK7PTjT+AHcGocCp30IZJkg/QsYmFhtuVhU8nW5l4UPPbmA==');
define('AUTH_SALT',        'MNFnBr33YSszcVIzQE4hBFTVbE5d2uuffafXJDI7Ui5Tt0HF1Ghof9tKv9illbn+JqtgwUDKFFcWAsGkTRE5KA==');
define('SECURE_AUTH_SALT', '2BiI8rKazQKckPqExJUZk6sWZV6+s6WpfrNEk1Mo7SVwudiZkQ6StGwiOy+a4rWsOE9/yGjlzGNn+siZZyPeOg==');
define('LOGGED_IN_SALT',   'JI3svUjMh/nK7SiYJCzuaIQlol1BSmlZRtwOoKWFQF3+gx1UoQ7zTOO0kf8SmzlpueA6u//aERy3N+FpON4Ahw==');
define('NONCE_SALT',       'qdWa7D2eAN9lVOIrpSub0O2RONKuPw2cgzc5B+ipzy6EQCeCU2jWghoCH00fo0Hj0rA1bplQyAbXeQBUpsQ50Q==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
